Jack Finio
PA5

Design Descisions:
	1. I used two different vectors in my network and user files, one called _friends and the other 	_users
	2. I use an array of strings to represent the id numbers of different users in return_friends so 		I can easily access different users

No known errors or memory leaks
