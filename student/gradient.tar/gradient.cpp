#include <iostream>
#include <cmath>
#include "bmplib.h"

using namespace std;

unsigned char bwimage[SIZE][SIZE];
unsigned char rgbimage[SIZE][SIZE][RGB];

// Prototypes
void draw_bw_gradient();
void draw_rgb_gradient(unsigned char sr,
		       unsigned char sg,
		       unsigned char sb,
		       unsigned char er,
		       unsigned char eg,
		       unsigned char eb);


int main()
{

  return 0;
}


void draw_bw_gradient()
{


}

void draw_rgb_gradient(unsigned char sr,
		       unsigned char sg,
		       unsigned char sb,
		       unsigned char er,
		       unsigned char eg,
		       unsigned char eb)
{

  
}
