#include <iostream>
#include <cmath>
#include "bmplib.h"

using namespace std;

unsigned char image[SIZE][SIZE];

// Prototypes
void draw_rectangle(int ulr, int ulc, int h, int w);
void draw_ellipse(int cr, int cc, int a, int b);


int main()
{

  // initialize the image to all white pixels
  for(int i=0; i < SIZE; i++){
    for(int j=0; j < SIZE; j++){
      image[i][j] = 255;
    }
  }

  // Main program loop here



  // Write the resulting image to the .bmp file
  writeGSBMP("output.bmp", image);

  return 0;
}

void draw_rectangle(int ulr, int ulc, int h, int w)
{

}

void draw_ellipse(int cr, int cc, int a, int b)
{

}
